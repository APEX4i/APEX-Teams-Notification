prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.2'
,p_default_workspace_id=>37107349341149668
,p_default_application_id=>100
,p_default_id_offset=>534273329313546068
,p_default_owner=>'CHECKTEST'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Request for Leave'
,p_alias=>'REQUEST-FOR-LEAVE'
,p_step_title=>'Request for Leave'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'RICHARD'
,p_last_upd_yyyymmddhh24miss=>'20240530151103'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(106918088816332326195)
,p_plug_name=>'Employee Details'
,p_region_template_options=>'#DEFAULT#:t-Region--accent15:t-Region--stacked:t-Region--scrollBody:t-Form--slimPadding'
,p_plug_template=>wwv_flow_imp.id(106940606717139504706)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(106978373598646522621)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(106940619060824504711)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(106940503237057504660)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(106940681515063504743)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(106918089581909326203)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(106918088816332326195)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--success:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(106940679896644504742)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(539496238379848609)
,p_branch_name=>'goto page 6'
,p_branch_action=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(535809203801667411)
,p_name=>'P3_EMAIL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(106918088816332326195)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(535809608824667415)
,p_name=>'P3_COMMENTS'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(106918088816332326195)
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(106940678664097504741)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106918088902653326196)
,p_name=>'P3_EMP_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(106918088816332326195)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106918089408461326201)
,p_name=>'P3_LEAVE_TYPE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(106918088816332326195)
,p_prompt=>'Leave Type'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Sick Leave;SL,Annual Leave;AL,Maternity Leave;ML,Vacation Leave;VL'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(106940677365337504740)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106918089448397326202)
,p_name=>'P3_NO_OF_DAYS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(106918088816332326195)
,p_prompt=>'No. of Days'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(106940677365337504740)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(106918088984106326197)
,p_computation_sequence=>10
,p_computation_item=>'P3_EMP_ID'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select emp_id from workflow_emp',
'where upper(emp_name) =upper(:APP_USER)'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(535809355097667412)
,p_computation_sequence=>20
,p_computation_item=>'P3_EMAIL'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select email from workflow_emp',
'where mrg = (select emp_id from workflow_emp where upper(emp_name) =upper(:APP_USER));'))
,p_compute_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(535809479211667413)
,p_name=>'Get Email'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_EMP_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(535809507366667414)
,p_event_id=>wwv_flow_imp.id(535809479211667413)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select email into :P3_EMAIL from workflow_emp',
'where emp_id = (select mrg from workflow_emp where upper(emp_name) =upper(:APP_USER));'))
,p_attribute_03=>'P3_EMAIL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_da_action_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select email into :P3_EMAIL from workflow_emp',
'where mrg = (select emp_id from workflow_emp where upper(emp_name) =upper(:APP_USER));'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(535809102364667410)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Notification to Teams'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_clob 	CLOB;',
'    l_json  CLOB;',
'    l_Workflow_URL VARCHAR2(2000);',
'    l_manager_text_msg CLOB;',
'    l_manager_email VARCHAR2(100);',
'    l_leave_days VARCHAR2(20);',
'    l_leave_type VARCHAR2(20);',
'    v_emp_name VARCHAR2(50);',
'    ',
' ',
'BEGIN',
'    l_Workflow_URL:=''https://prod-17.centralindia.logic.azure.com:443/workflows/f8362bc211bc49ed8e4c7829d91f430b/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=f96F4GJPu8_Wr7vfVahxuZK3Oh1tE3ri8Fkqfg9Q988'''
||';',
'    --select CHAR_VALUE into l_Workflow_URL from XXFS_PM_PARAMETERS_T where CODE=''TEAMS_WORKFLOW_URL'';',
'    l_manager_email:=:P3_EMAIL;',
'    l_leave_days:=:P3_NO_OF_DAYS;',
'    l_manager_text_msg :=:P3_COMMENTS;',
'    l_leave_type:=:P3_LEAVE_TYPE;',
'',
'    BEGIN ',
'        SELECT EMP_NAME INTO v_emp_name',
'        FROM WORKFLOW_EMP ',
'        WHERE EMP_ID = :P3_EMP_ID;',
'    EXCEPTION WHEN OTHERS THEN ',
'        v_emp_name:=NULL;',
'    END;',
'    ',
'        l_json := ''{',
'          "to": "'' || l_manager_email || ''",',
'          "subject": "Leave Request from '' || v_emp_name || ''",',
'          "Leave Type": "'' || l_leave_type || ''",',
'          "Leave Days": "'' || l_leave_days || ''",',
'          "message": "'' || l_manager_text_msg || ''"',
'        }'';',
'',
'        apex_web_service.g_request_headers(1).name  := ''Content-Type'';',
'        apex_web_service.g_request_headers(1).value := ''application/json'';',
'       -- DBMS_OUTPUT.PUT_LINE(''l_json''|| l_json);',
'        l_clob := apex_web_service.make_rest_request(',
'            p_url => l_Workflow_URL,',
'            p_http_method => ''POST'',',
'            p_body=> l_json);',
'       --dbms_output.put_line(l_json);',
'END ;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(106918089581909326203)
,p_internal_uid=>535809102364667410
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(106918089090120326198)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CREATE_TASK'
,p_process_name=>'Leave Request'
,p_attribute_01=>wwv_flow_imp.id(106959753695065643499)
,p_attribute_05=>'P3_EMP_ID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Leave Request has been submitted successfully.'
,p_internal_uid=>106383815760806780130
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(106918089130598326199)
,p_page_id=>3
,p_task_def_param_id=>wwv_flow_imp.id(106971846852065479910)
,p_page_process_id=>wwv_flow_imp.id(106918089090120326198)
,p_value_type=>'ITEM'
,p_value=>'P3_LEAVE_TYPE'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(106918089303430326200)
,p_page_id=>3
,p_task_def_param_id=>wwv_flow_imp.id(106971847218178479910)
,p_page_process_id=>wwv_flow_imp.id(106918089090120326198)
,p_value_type=>'ITEM'
,p_value=>'P3_NO_OF_DAYS'
);
wwv_flow_imp.component_end;
end;
/
