prompt --application/shared_components/logic/application_processes/get_send_mail
begin
--   Manifest
--     APPLICATION PROCESS: get send mail
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.2'
,p_default_workspace_id=>37107349341149668
,p_default_application_id=>100
,p_default_id_offset=>534273329313546068
,p_default_owner=>'CHECKTEST'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(535974114929923163)
,p_process_sequence=>1
,p_process_point=>'AFTER_LOGIN'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get send mail'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select email into :SEND_MAIL from workflow_emp',
'where upper(emp_name) =upper(:APP_USER);'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>10142178934177
);
wwv_flow_imp.component_end;
end;
/
