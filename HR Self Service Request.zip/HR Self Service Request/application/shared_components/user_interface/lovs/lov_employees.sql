prompt --application/shared_components/user_interface/lovs/lov_employees
begin
--   Manifest
--     LOV_EMPLOYEES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.2'
,p_default_workspace_id=>37107349341149668
,p_default_application_id=>100
,p_default_id_offset=>534273329313546068
,p_default_owner=>'CHECKTEST'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(539456576837809982)
,p_lov_name=>'LOV_EMPLOYEES'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'WORKFLOW_EMP'
,p_return_column_name=>'EMP_ID'
,p_display_column_name=>'EMP_NAME'
,p_default_sort_column_name=>'EMP_NAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
