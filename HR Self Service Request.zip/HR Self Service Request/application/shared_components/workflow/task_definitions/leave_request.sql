prompt --application/shared_components/workflow/task_definitions/leave_request
begin
--   Manifest
--     TASK_DEF: Leave Request
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.2'
,p_default_workspace_id=>37107349341149668
,p_default_application_id=>100
,p_default_id_offset=>534273329313546068
,p_default_owner=>'CHECKTEST'
);
wwv_flow_imp_shared.create_task_def(
 p_id=>wwv_flow_imp.id(106959753695065643499)
,p_name=>'Leave Request'
,p_static_id=>'LEAVE_REQUEST'
,p_subject=>'Leave Request &LEAVE_TYPE. for &EMP_NAME.'
,p_task_type=>'APPROVAL'
,p_priority=>2
,p_expiration_policy=>'NONE'
,p_max_renewal_count=>3
,p_details_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:RP,2:P2_TASK_ID:&TASK_ID.'
,p_actions_sql_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select w.emp_id,w.emp_name,a.emp_name as mgr_name from workflow_emp w , workflow_emp a ',
'where a.emp_id(+) = w.mrg ',
'and w.emp_id =:APEX$TASK_PK'))
);
wwv_flow_imp_shared.create_task_def_param(
 p_id=>wwv_flow_imp.id(106971846852065479910)
,p_task_def_id=>wwv_flow_imp.id(106959753695065643499)
,p_label=>'Leave Type'
,p_static_id=>'LEAVE_TYPE'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_visible=>true
);
wwv_flow_imp_shared.create_task_def_param(
 p_id=>wwv_flow_imp.id(106971847218178479910)
,p_task_def_id=>wwv_flow_imp.id(106959753695065643499)
,p_label=>'No Of Days'
,p_static_id=>'NO_OF_DAYS'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_visible=>true
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(106973873290978495659)
,p_task_def_id=>wwv_flow_imp.id(106959753695065643499)
,p_name=>'Approved'
,p_execution_sequence=>10
,p_outcome=>'APPROVED'
,p_on_event=>'COMPLETE'
,p_action_type=>'NATIVE_SEND_EMAIL'
,p_attribute_01=>'&SEND_MAIL.'
,p_attribute_02=>'kenvi.shah@4iapps.com'
,p_attribute_06=>'Leave Request Details'
,p_attribute_07=>'Your Leave Request for &LEAVE_TYPE. is APPROVED.'
,p_attribute_10=>'N'
,p_attribute_14=>'HTML'
,p_location=>'LOCAL'
,p_success_message=>'Leave Request Approved.'
,p_stop_execution_on_error=>true
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(107083904818629740979)
,p_task_def_id=>wwv_flow_imp.id(106959753695065643499)
,p_name=>'Update Status'
,p_execution_sequence=>20
,p_outcome=>'APPROVED'
,p_on_event=>'COMPLETE'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Update LEAVE_REQ set APPROVED_BY=:APP_USER,',
'APPROVED_ON= sysdate,',
'STATUS = ''A''',
'where emp_id = :APEX$TASK_PK;'))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_success_message=>'Data Updated Successfully...'
,p_stop_execution_on_error=>true
,p_condition_type=>'NEVER'
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(106970644679964745937)
,p_task_def_id=>wwv_flow_imp.id(106959753695065643499)
,p_participant_type=>'POTENTIAL_OWNER'
,p_identity_type=>'USER'
,p_value_type=>'SQL_QUERY'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select emp_name from workflow_emp ',
'where emp_id =(select mrg from workflow_emp ',
'                               where emp_id = :APEX$TASK_PK);'))
);
wwv_flow_imp.component_end;
end;
/
